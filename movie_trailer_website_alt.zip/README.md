# Movie Trailer Website
Source code for a Movie Trailer Website, as per the first Final Project from the Udacity Full-Stack Developer Nanodegree.

## Directions

- Download the movie_trailer_website.zip folder and unzip to the document root (or desired filepath).
- In Python shell, open and run **favorites.py** in the newly unzipped folder.  The program will compile two new .pyc files and an .html file.
- Open and view fresh_tomatoes.html file with your web browser.

**NOTE:** To view on a machine without Python installed, you can alternatively download the larger movie_trailer_website_alt.zip folder, which contains all necessary resources after running the **favorites.py** program.